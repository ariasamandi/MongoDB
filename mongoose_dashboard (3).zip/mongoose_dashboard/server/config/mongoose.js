const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/mongoose_dashboard');