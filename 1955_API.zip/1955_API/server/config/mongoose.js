const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/1955_API');
