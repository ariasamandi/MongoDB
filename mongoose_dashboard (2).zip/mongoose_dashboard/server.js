const express = require('express');
const app = express();
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');
app.use(bodyParser.urlencoded({ extended: true }));
// Setting our Views Folder Directory
app.set('views', path.join(__dirname, './views'));
// Setting our View Engine set to EJS
app.set('view engine', 'ejs');
// Routes
// Root Request
mongoose.connect('mongodb://localhost/mongoose_dashboard');

var UserSchema = new mongoose.Schema({
    name: {type: String, required: true, minlength: [2, "name must be 2 or more charcters"]},
    age: {type: Number, required: true, min: [2, "Mongoose must be 2 or older"]},
})
mongoose.model('Mongoose', UserSchema); // We are setting this Schema in our Models as 'User'
var Mongoose = mongoose.model('Mongoose') // We are retrieving this Schema from our Models, named 'User'
   // Use native promises
mongoose.Promise = global.Promise;

app.get('/', (req, res)=> {
    Mongoose.find({}, (err, mongooses)=>{
        if(err){
            console.log(err);
            console.log("We got some errors");
        }
        else{
            res.render('index', {allMongooses: mongooses});
        }
    })
})
app.get('/mongooses/new', (req, res)=> {
    res.render('new');
    // res.redirect('/')
})
app.post('/mongoose', (req, res)=>{
    Mongoose.create({name: req.body.name, age: req.body.age}, (err, data)=>{
        if(err){
            console.log(err);
            for(var e in err.errors){
                console.log(e);
                req.flash('myerror', err.errors[e].message)
            }
        }
        else{
        
            console.log("this is the create method")
            res.redirect('/')
        }
    })
})
app.post('/mongooses/destroy/:id', (req, res)=>{
    Mongoose.remove({_id: req.params.id}, (err, data)=>{
        if(err){
            console.log(err);
        }
        else{
            console.log("sucess")
            res.redirect('/')
        }
    })
})
app.get('/mongooses/:id', (req, res)=> {
    Mongoose.findById({_id:req.params.id}, (err, goose)=>{
        if(err){
            console.log(err);
        }
        else{
            console.log(goose);
            res.render("show", {goose: goose});
        }
       
    })
})


app.get('/mongooses/edit/:id', (req, res)=> {
    Mongoose.findOne({_id: req.params.id}, (err, goose)=>{
        if(err){
            console.log(err);
            res.redirect('/');
        }
        else{
            res.render("edit", {goose: goose});
        }
    })
})
app.post('/mongooses/:id', (req, res)=>{
    Mongoose.update({_id: req.params.id}, req.body, (err, data)=>{
        if(err){
            console.log(err);
            res.redirect(`/mongooses/edit/${req.params.id}`)
        }
        else{
            console.log("we did it" + data);
            res.redirect('/')
        }
    })
})
app.listen(8000, function() {
    console.log("listening on port 8000");
})
